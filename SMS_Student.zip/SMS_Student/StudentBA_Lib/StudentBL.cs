﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentDAL_Lib;
using StudentEntites;

namespace StudentBA_Lib
{
    public class StudentBL
    {
        
        public static void Add(Student student)
        {
          StudentDAL.Insert(student);
        }


        public static void modify(Student student)
        {
            StudentDAL.Update(student);
        }
    }
}
