﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentEntites;
using System.Data.SqlClient;


namespace StudentDAL_Lib
{
    public class StudentDAL
    {
        static SqlConnection cn = null;
        static SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
        }
        public static void Insert(Student student)
        {
            cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            cmd = new SqlCommand("insert into H189821.Student values(@fullName,@gender,@email,@add,@dob,@mobNo,@state)", cn);
            cmd.Parameters.AddWithValue("@fullName", student.FullName);
            cmd.Parameters.AddWithValue("@gender", student.Gender);
            cmd.Parameters.AddWithValue("@dob", student.DOB);
            cmd.Parameters.AddWithValue("@mobNo", student.MobileNo);
            cmd.Parameters.AddWithValue("@email", student.Email);
            cmd.Parameters.AddWithValue("@state", student.State);
            cmd.Parameters.AddWithValue("@add", student.Address);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        public static void Update(Student student)
        {
            cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            cmd = new SqlCommand("Update H189821.Student set fullName=@fullName,gender=@gender,email=@email,Addr=@add,DOB=@dob,mobile=@mobNo,states =@state Where rollno=@rollno", cn);
            cmd.Parameters.AddWithValue("@fullName", student.FullName);
            cmd.Parameters.AddWithValue("@gender", student.Gender);
            cmd.Parameters.AddWithValue("@dob", student.DOB);
            cmd.Parameters.AddWithValue("@mobNo", student.MobileNo);
            cmd.Parameters.AddWithValue("@email", student.Email);
            cmd.Parameters.AddWithValue("@state", student.State);
            cmd.Parameters.AddWithValue("@add", student.Address);

            cmd.Parameters.AddWithValue("@rollno", student.rollno);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }
    }
}
