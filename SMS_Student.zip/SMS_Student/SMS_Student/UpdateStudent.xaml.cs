﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using StudentEntites;
using StudentBA_Lib;
using StudentDAL_Lib;

namespace SMS_Student
{
    /// <summary>
    /// Interaction logic for UpdateStudent.xaml
    /// </summary>
    public partial class UpdateStudent : Window
    {
        public UpdateStudent()
        {
            InitializeComponent();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Student student = new Student
            {
                rollno = Convert.ToInt32(txtRollNo.Text),
                FullName = txtFullName.Text,
                DOB = (DateTime)txtDOB.SelectedDate,
                MobileNo = txtMobNo.Text,
                Email = txtEmail.Text,
                State = ((ListBoxItem)lbState.SelectedItem).Content.ToString()
            };
            string gender = string.Empty;
            if (rbMale.IsChecked == true)
                gender = rbMale.Content.ToString();
            else if (rbFemale.IsChecked == true)
                gender = rbFemale.Content.ToString();
            student.Gender = gender;
            txtAddress.SelectAll();
            student.Address = txtAddress.Selection.Text;
            StudentBL.modify(student);
            MessageBox.Show("Record Updated Successfully!");
        }
    }
}
